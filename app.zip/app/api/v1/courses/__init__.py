# Courses API module 
from .main import router 